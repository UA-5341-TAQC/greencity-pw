import type { Page, Locator } from '@playwright/test';
import { BaseComponent } from '@/components/base-component';

export abstract class BaseEventCardComponent extends BaseComponent {
  protected readonly bookmarkButton: Locator;
  protected readonly image: Locator;
  protected readonly typeTag: Locator;
  protected readonly participantsCountText: Locator;
  protected readonly eventDate: Locator;
  protected readonly eventTime: Locator;
  protected readonly eventLocation: Locator;
  protected readonly eventStatus: Locator;
  protected readonly eventTitle: Locator;
  protected readonly moreButton: Locator;
  protected readonly editEventButton: Locator;
  protected readonly joinEventButton: Locator;
  protected readonly publishDate: Locator;
  protected readonly authorName: Locator;
  protected readonly commentsCount: Locator;
  protected readonly likeButton: Locator;
  protected readonly likeCount: Locator;
  protected readonly dislikeButton: Locator;
  protected readonly dislikeCount: Locator;

  constructor(root: Locator, page?: Page) {
    super(root, page);

    this.bookmarkButton = this.root.locator('div.event-flags.favourite-button');
    this.image = this.root.locator('img.event-image');
    this.typeTag = this.root.locator('ul.ul-eco-buttons a.tag');
    this.participantsCountText = this.root.locator('span.event-participants-count');

    this.eventDate = this.root.locator('div.date-container div.date');
    this.eventTime = this.root.locator('div.date-container div.time');
    this.eventLocation = this.root.locator('div.date-container p');
    this.eventStatus = this.root.locator('div.event-status');

    this.eventTitle = this.root.locator('p.event-name');
    this.moreButton = this.root.getByRole('button', { name: 'More' });
    this.editEventButton = this.root.getByRole('button', { name: 'Edit event' });
    this.joinEventButton = this.root.getByRole('button', { name: 'Join event' });

    this.publishDate = this.root.locator('div.additional-info div.date p');
    this.authorName = this.root.locator('div.additional-info div.author p');
    this.commentsCount = this.root.locator('div.additional-info div.frame p');
    this.likeButton = this.root
      .locator('div.additional-info')
      .getByRole('button', { name: 'Like this event' });
    this.likeCount = this.likeButton.locator('span');
    this.dislikeButton = this.root
      .locator('div.additional-info')
      .getByRole('button', { name: 'Dislike this event' });
    this.dislikeCount = this.dislikeButton.locator('span');
  }
  /** Clicks the bookmark button on the card */
  async clickBookmarkButton(): Promise<void> {
    await this.bookmarkButton.click();
  }

  async hasBookmarkButton(): Promise<boolean> {
    return (await this.bookmarkButton.count()) > 0;
  }

  /** Hovers the card so its bookmark button is rendered */
  async hoverBookmarkButton(): Promise<void> {
    await this.root.hover();
    await this.bookmarkButton.waitFor({ state: 'visible' });
  }

  /** Returns the bookmark button's rendered styles to verify its selected state */
  async getBookmarkButtonState(): Promise<string> {
    return await this.bookmarkButton.evaluate((element) => {
      const summarize = (item: Element | null) => {
        if (!item) return null;

        const styles = (pseudo: string) => {
          const style = getComputedStyle(item, pseudo);
          return [
            style.backgroundImage,
            style.backgroundPosition,
            style.backgroundColor,
            style.color,
            style.opacity,
            style.content,
          ];
        };

        return {
          html: item.outerHTML,
          attributes: Array.from(item.attributes).map(({ name, value }) => [name, value]),
          style: styles(''),
          before: styles('::before'),
          after: styles('::after'),
        };
      };

      return JSON.stringify({
        button: summarize(element),
        flag: summarize(element.querySelector('.flag')),
      });
    });
  }

  /** Checks whether the event image is visible */
  async isImageVisible(): Promise<boolean> {
    return await this.image.isVisible();
  }

  /** Returns the event type text  */
  async getType(): Promise<string> {
    return (await this.typeTag.textContent()) ?? '';
  }

  /** Returns the event date text  */
  async getDate(): Promise<string> {
    return (await this.eventDate.textContent()) ?? '';
  }

  /** Returns the event time text  */
  async getTime(): Promise<string> {
    return (await this.eventTime.textContent()) ?? '';
  }

  /** Returns the event location text */
  async getLocation(): Promise<string> {
    return (await this.eventLocation.textContent()) ?? '';
  }

  /** Returns the event status text  */
  async getStatus(): Promise<string> {
    return (await this.eventStatus.textContent()) ?? '';
  }

  /** Returns the event title text */
  async getTitle(): Promise<string> {
    return (await this.eventTitle.innerText()).trim();
  }

  /** Clicks the "More" button */
  async clickMore(): Promise<void> {
    await this.moreButton.click();
  }

  /** Checks whether the "Edit event" button is visible */
  async isEditEventButtonVisible(): Promise<boolean> {
    return await this.editEventButton.isVisible();
  }

  /** Checks whether the "Edit event" button is enabled */
  async isEditEventButtonEnabled(): Promise<boolean> {
    return await this.editEventButton.isEnabled();
  }

  /** Clicks the "Edit event" button */
  async clickEditEvent(): Promise<void> {
    await this.editEventButton.click();
  }

  /** Clicks the "Join event" button */
  async clickJoinEvent(): Promise<void> {
    await this.joinEventButton.click();
  }

  /** Checks whether the "Join event" button is enabled */
  async isJoinEventEnabled(): Promise<boolean> {
    return await this.joinEventButton.isEnabled();
  }

  /** Returns the event publish date text  */
  async getPublishDate(): Promise<string> {
    return (await this.publishDate.textContent()) ?? '';
  }

  /** Returns the event author's name */
  async getAuthorName(): Promise<string> {
    return (await this.authorName.textContent()) ?? '';
  }

  /** Returns the comments count as a number  */
  async getCommentsCount(): Promise<number> {
    const text = (await this.commentsCount.textContent()) ?? '0';
    return Number(text.trim());
  }

  /** Clicks the "Like" button */
  async clickLike(): Promise<void> {
    await this.likeButton.click();
  }

  /** Returns the like count as a number */
  async getLikeCount(): Promise<number> {
    const text = (await this.likeCount.textContent()) ?? '0';
    return Number(text.trim());
  }

  /** Clicks the "Dislike" button */
  async clickDislike(): Promise<void> {
    await this.dislikeButton.click();
  }

  /** Returns the dislike count as a number */
  async getDislikeCount(): Promise<number> {
    const text = (await this.dislikeCount.textContent()) ?? '0';
    return Number(text.trim());
  }

  /** Returns the extra-participants count text (e.g. "1") */
  async getParticipantsCountText(): Promise<string> {
    return (await this.participantsCountText.textContent()) ?? '';
  }
  /** Checks whether this card's root element matches the expected view mode */
  abstract isCorrectViewMode(): Promise<boolean>;
}
