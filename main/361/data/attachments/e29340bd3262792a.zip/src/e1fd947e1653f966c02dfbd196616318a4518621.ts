import { expect, Locator, Page, test } from '@playwright/test';
import { BaseComponent } from '@/components/base-component';
import { Language, MenuItem } from '@/types/header.types';
import { HEADER_I18N, type HeaderI18n } from '@/types/header.i18n';
import env from '@/config/env';

export type { Language, MenuItem };

/**
 * Component representing the global header.
 * Contains navigation links, language switcher, auth buttons, and user menu.
 */
export class HeaderComponent extends BaseComponent {
  // Navigation
  readonly logo: Locator;
  private readonly navLinks: Record<MenuItem, Locator>;

  // Utilities
  readonly searchIcon: Locator;
  readonly languageSwitcher: Locator;
  readonly langEnglishOption: Locator;
  readonly langUkrainianOption: Locator;

  // Auth & Profile
  readonly signInButton: Locator;
  readonly signUpButton: Locator;
  readonly userMenuDropdown: Locator;
  readonly signOutButton: Locator;

  constructor(page: Page) {
    super(page.locator('header').first(), page);

    // Navigation Locators
    this.logo = this.root.locator('a.header_logo');
    this.navLinks = {
      [MenuItem.EcoNews]: this.localizedLink((i18n) => i18n.navigation[MenuItem.EcoNews]),
      [MenuItem.Events]: this.localizedLink((i18n) => i18n.navigation[MenuItem.Events]),
      [MenuItem.Places]: this.localizedLink((i18n) => i18n.navigation[MenuItem.Places]),
      [MenuItem.AboutUs]: this.localizedLink((i18n) => i18n.navigation[MenuItem.AboutUs]),
      [MenuItem.MySpace]: this.localizedLink((i18n) => i18n.navigation[MenuItem.MySpace]),
    };

    // Utilities Locators
    this.searchIcon = this.root.getByLabel('site search');
    this.languageSwitcher = this.root.getByLabel('language switcher');
    this.langEnglishOption = this.root.getByLabel('english');
    this.langUkrainianOption = this.root.getByLabel('Uk');

    // Auth & Profile Locators
    this.signInButton = this.localizedLink((i18n) => i18n.signIn);
    this.signUpButton = this.localizedLink((i18n) => i18n.signUp);
    this.userMenuDropdown = this.root.locator('#header_user-wrp');
    this.signOutButton = this.localizedLink((i18n) => i18n.signOut);
  }

  private localizedLink(getText: (i18n: HeaderI18n) => string): Locator {
    const names = Object.values(HEADER_I18N).map((i18n) =>
      getText(i18n).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    );
    return this.root.getByRole('link', { name: new RegExp(`^(?:${names.join('|')})$`, 'i') });
  }

  // --- State Methods ---

  /**
   * Checks if the user is currently logged in by looking for the user menu dropdown.
   * @returns true if the user menu is visible, false otherwise.
   */
  async isLoggedIn(): Promise<boolean> {
    return await test.step('Check if user is logged in', async () => {
      try {
        await this.userMenuDropdown.waitFor({ state: 'visible', timeout: env.SHORT_TIMEOUT });
        return true;
      } catch {
        return false;
      }
    });
  }

  /**
   * Gets the current language from the header.
   * @returns 'En' if the current language is English, 'Uk' if it's Ukrainian.
   */
  async getCurrentLanguage(): Promise<Language> {
    return await test.step('Get current language from header', async () => {
      const text = await this.languageSwitcher.innerText();
      return text.trim() as Language;
    });
  }

  // --- Utilities Methods ---

  async switchLanguage(language: Language): Promise<void> {
    await test.step(`Switch language to ${language}`, async () => {
      if ((await this.getCurrentLanguage()) !== language) {
        await this.languageSwitcher.click();
        if (language === Language.En) {
          await this.langEnglishOption.click();
        } else {
          await this.langUkrainianOption.click();
        }
        // Verify that the language has been switched
        const expectedText = HEADER_I18N[language].navigation[MenuItem.EcoNews];
        await expect(this.navLinks[MenuItem.EcoNews]).toContainText(expectedText, {
          ignoreCase: true,
        });
      }
    });
  }

  async openSearch(): Promise<void> {
    await test.step('Open search', async () => {
      await this.searchIcon.click();
    });
  }

  // --- Auth & Profile Methods ---

  /**
   * Clicks the "Sign in" button in the header.
   */
  async clickSignIn(): Promise<void> {
    await test.step('Click Sign In button', async () => {
      await this.signInButton.click();
    });
  }

  async clickSignUp(): Promise<void> {
    await test.step('Click Sign Up button', async () => {
      await this.signUpButton.click();
    });
  }

  async openUserMenu(): Promise<void> {
    await test.step('Open User Menu dropdown', async () => {
      await this.userMenuDropdown.click();
    });
  }

  async clickSignOut(): Promise<void> {
    await test.step('Click Sign Out', async () => {
      await this.openUserMenu();
      await this.signOutButton.click();
    });
  }

  // --- Navigation Methods ---

  async clickLogo(): Promise<void> {
    await test.step('Click on Logo', async () => {
      await this.logo.click();
    });
  }

  /**
   * Navigates to a specific section via the header navigation menu.
   * Automatically handles multilingual matching.
   * @param item - The menu item to navigate to (e.g., "Eco news", "Events").
   */
  async navigateTo(item: MenuItem): Promise<void> {
    await test.step(`Navigate to ${item} via Header`, async () => {
      await this.navLinks[item].click();
    });
  }

  /**
   * Helper for veryfing all navigation links are visible
   */
  async verifyAllNavLinksAreVisible(): Promise<void> {
    for (const [menuItem, locator] of Object.entries(this.navLinks)) {
      await expect(locator, `Header menu option ${menuItem} should be visible!`).toBeVisible();
    }
  }
}
